from Student import Student
from Meeting import  Meeting
from MeelingList import  AllMeetings
from  StudentList import AllStudents
from datetime import datetime, timedelta

class Application:
    def __init__(self):
        self._students = AllStudents()
        self._meetings = AllMeetings()

    def read_data(self):
        meeting_file = 'meetings.csv'
        student_file = 'students_meeting.csv'
        with open(meeting_file) as file:
            for line in file:
                line = line .strip()
                row = line.split(', ')
                print(row)
                meeting_id, name, description, start_time, duration, total_capacity, price = row
                meeting_id = int(meeting_id)
                start_time = datetime.strptime(start_time, '%d/%m/%Y %H:%M')
                duration = int(duration)
                total_capacity = int(total_capacity)
                price = float(price)

                meeting = Meeting(meeting_id, name, description, start_time, duration, total_capacity, price)
                self._meetings.add_meeting(meeting)

        with open(student_file) as file:
            for line in file:
                line = line .strip()
                row = line.split(', ')
                student_id, name, age, phone = row[:4]
                student_id = int(student_id)
                age = int(age)
                meeting_ids = row[4:]
                student = Student(student_id, name, age, phone)
                self._students.add_student(student)
                for meeting_id in meeting_ids:
                    meeting_id = int(meeting_id)
                    self._meetings.add_student_to_meeting(meeting_id, student)

    def get_meeting_sorted_by_id(self):
        meetings = self._meetings.get_all_meetings_by_id()
        for meeting in meetings:
            print(meeting)
    def welcome_message(self):
        message = 'Welcome to the event mangement application'
        print(message)
        print('*' * len(message))
    def print_menu(self):
        print()
        print('Menu')
        print('*****************')
        print(f'''
1. get all meetings  sorted by id
2. get all meetings sorted by name
3. get all meetings sorted by price
4. get all students of a meeting
5. get all meetings a stundent
6. delete a meeting
7. delete a student from a meeting
8. delete a student completely.
9. Get students without any meetings.
10. search meeting by keyword
11. search student by name
12. search student by phone
0. Quit

''')


def main():
    app = Application()
    app.read_data()
    app.welcome_message()
    while True:
        app.print_menu()
        choice = int(input('Enter the menu choice:'))
        if choice == 1:
            app.get_meeting_sorted_by_id()

        elif choice == 0:
            print('bye')
            break


main()

# 30/10/2023 09:00