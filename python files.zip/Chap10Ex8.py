import package1
print(dir())
print(dir(package1))

print(help(package1)) # displays the details related to the init file.
