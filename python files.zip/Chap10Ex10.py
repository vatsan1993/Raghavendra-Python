import math
print(math.gcd(5, 10, 15, 20))


# or
# from math import gdc

import os

print(os.name)

print(os.listdir("./"))

path = os.path.join("./", "package1")

print(os.listdir(path))


# read about os.walk

# important modules
# os, sys, math, random, processing, itertools, functools, csv, sqlite, json, datetime, tkinter.